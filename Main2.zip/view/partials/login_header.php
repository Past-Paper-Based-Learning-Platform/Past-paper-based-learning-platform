<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="libs/main.css" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body onload="signupDisplay()">
    <div class="tab">
        <div class="col-2-item">
        <a href='http://localhost/Main2/index.php?page=login.php'><button>Login</button></a>
        </div>
        <div class="col-2-item">
        <a href='http://localhost/Main2/index.php?page=signup.php'><button>Signup</button></a>
        </div>
    </div>