<!DOCTYPE html>
<head>
    <style>
    .post{
        width: 100%;
        border: 1px solid #000099;
        border-radius: 4px;
        background-color: #ccccff;
        margin: 5px;
    }
    .post img{
        width: 95%;
        padding: 10px;
    }
    </style>
</head>

<body>
    <div class="post parent">
        <h3>1 -> b -> i  <br> Post id Q</h3><br>
        <p><a href="#">#KMP_algorithm</a> <a href="#">#String matching</a> <a href="#" style="text-decoration: none;">&#127991;</a></p>
        <p><b>What is the pi funtion of this string?</b></p>
        <img src="../../pictures/1-b-i.PNG"><br>
        <p>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128077;</a>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128078;</a>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128172;</a>
            <a href="#" style="text-decoration: none; margin: 10px; float: right;">&#11093;</a>
        </p>
    </div>

    <div class="post parent">
        <h3>1 -> b -> i  <br> Parent post id A</h3><br>
        <p><b>Pi= 0|0|0|0|0|0|1</b></p>
        <p>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128077;</a>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128078;</a>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128172;</a>
            <a href="#" style="text-decoration: none; margin: 10px; float: right;">&#11093;</a>
        </p>
    </div>

    <div class="post parent">
        <h3>1 -> b -> i  <br> Parent post id Q</h3><br>
        <p><b>How to solve that problem?</b></p>
        <p>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128077;</a>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128078;</a>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128172;</a>
            <a href="#" style="text-decoration: none; margin: 10px; float: right;">&#11093;</a>
        </p>
    </div>

    <div class="post parent">
        <h3>1 -> b -> i  <br> Parent post id A</h3><br>
        <img src="../../pictures/1-b-i-A.PNG"><br>
        <p>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128077;</a>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128078;</a>
            <a href="#" style="text-decoration: none; margin: 10px;">&#128172;</a>
            <a href="#" style="text-decoration: none; margin: 10px; float: right;">&#11093;</a>
        </p>
    </div>
</body>
</html>