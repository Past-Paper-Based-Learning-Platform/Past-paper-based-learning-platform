<?php include 'view/partials/lecturer_header.php';?>
                        <!-- Scedule meeting Content -->
                        <div>
                            <h2>Schedule Meeting</h2>
                            <ul>
                                <li><p>meeting request 1 <a href="#">confirm</a> <a href="#">deny</a></p></li>
                                <li><p>meeting request 2 <a href="#">confirm</a> <a href="#">deny</a></p></li>
                                <li><p>meeting request 3 <a href="#">confirm</a> <a href="#">deny</a></p></li>
                                <li><p>meeting request 4 <a href="#">confirm</a> <a href="#">deny</a></p></li>
                            </ul>
                        </div>
<?php include 'view/partials/lecturer_footer.php';?>  