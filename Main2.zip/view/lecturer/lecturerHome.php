<?php include 'view/partials/lecturer_header.php';?>
                        <!-- HOME default content -->
                        <div>
                            <h1>Content<?php echo "<pre>"; print_r($_SESSION); "</pre>"; ?></h1>
                        </div>
<?php include 'view/partials/lecturer_footer.php';?>             